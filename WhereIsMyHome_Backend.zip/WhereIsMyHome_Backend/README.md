# PJT readme.md

# 1. 메인페이지
<img width="1469" alt="main" src="https://user-images.githubusercontent.com/31893342/236118871-f5186553-1424-4d4d-9845-d6ecea6afd2c.png">

> ### 1.  (1) 상단 메뉴바에서 회원가입, 로그인을 할 수 있다. <br>
> ### (2) 시/도, 구/군, 동을 선택하면 동별 실거래과 검색 결과 페이지로 이동한다.

# 2. 동별 실거래가 검색 결과 페이지
<img width="1469" alt="search" src="https://user-images.githubusercontent.com/31893342/236118988-6108ea4b-1c53-4227-88bc-2cb8d76a117d.png">

> ### (1) 선택한 지역의 지도와 거래 내역을 보여준다. <br>
> ### (2) 거래 내역을 클릭하면 해당 좌표로 지도를 이동시킨다.

# 3. 회원가입
<img width="1469" alt="signup" src="https://user-images.githubusercontent.com/31893342/236119017-f568a936-c449-48e5-add4-d390d9853fa5.png">

> ### 회원 정보를 입력하고 회원 가입을 한다. <br>
> 아이디 : ssafy <br>
> 비밀번호 : ssafy1 <br>
> 이름 : 김싸피 <br>
> 주소 : 구미 <br>
> 전화번호 : 054-1234-5678 <br>

# 4. 로그인
<img width="1469" alt="signin" src="https://user-images.githubusercontent.com/31893342/236119046-17598b35-aa04-4942-9dcd-eb24a5f6d325.png">

> ### 아이디, 비밀번호를 입력하여 로그인을 한다. <br>
> 아이디 : ssafy
> 비밀번호 : ssafy1

<img width="1469" alt="signin-ok" src="https://user-images.githubusercontent.com/31893342/236119090-913271cd-0bb5-4db1-bde9-27623096720f.png">

> ### 로그인에 성공하면, 상단 메뉴바가 변경된다. (로그인, 회원가입 → 로그아웃)

# 5. 마이페이지
<img width="1469" alt="mypage" src="https://user-images.githubusercontent.com/31893342/236119127-0e742601-d6c7-48b8-824f-8d3e043a7511.png">

> ### 정보를 수정하거나, 회원 탈퇴를 할 수 있다.
