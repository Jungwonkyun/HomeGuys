package com.ssafy.home.WhereIsMyHomeSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhereIsMyHomeSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
